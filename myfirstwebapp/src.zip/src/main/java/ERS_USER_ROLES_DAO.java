public interface ERS_USER_ROLES_DAO {
    String Find_User_Role(int user_role_id);
}

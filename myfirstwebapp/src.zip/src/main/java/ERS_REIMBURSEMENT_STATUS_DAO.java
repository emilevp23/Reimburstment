public interface ERS_REIMBURSEMENT_STATUS_DAO {
    String Reimbursement_Status(int reimbursement_status_id);
}
